========================================================================
AMK MULTI-BOOT APP LAUNCHER - COMPLETE SD CARD STARTER KIT
========================================================================

Author: Aung Moe Khine
Compatibility: ESP32 Cheap Yellow Displays (2.4", 2.8", 3.2", 3.5")

INCLUDED APPLICATIONS (in /apps/):
1. FlightRadar.bin       - Live ADS-B Aircraft Tracking with OpenStreetMap
2. FlipClock.bin         - Retro Split-Flap Clock with NTP TimeSync
3. TouchCalibration.bin  - Precision Touchscreen Calibration Tool
4. WeatherStation2.8.bin - Full Weather Station with 7-Day Forecast (2.8" CYD)
5. WeatherStation3.5.bin - High-Resolution Weather Station (3.5" CYD)

SUPPORTING ROOT FOLDERS (MUST remain in SD card Root!):
- /BMP32X32/  - Compact Weather Icons
- /BMP64x64/  - Large High-Res Weather Icons
- /flags/     - Country Flags for World Clocks
- /Logo/      - System & App Logos

QUICK START:
1. Format your MicroSD card with FAT32.
2. Extract all folders directly to the root of your MicroSD card.
3. Insert into your CYD display and power on!
4. Double-tap the screen during the 5s boot countdown to select any app!
========================================================================
